# Copyright (C) 2001-2006 Python Software Foundation

# Standard distutils setup.py install script for the `mimelib' library, a next
# generation MIME library for Python.  To install into your existing Python
# distribution, run the following at the command line:
#
# % python setup.py install

from distutils.core import setup

setup(name='email',
      version='4.0.3',
      description='Standalone email package (mod by tkikuchi)',
      author='Barry Warsaw',
      author_email='email-sig@python.org',
      url='http://www.python.org/sigs/email-sig',
      packages=['email', 'email.mime'],
      #package_dir={'email': 'email', 'email.mime': 'email/mime'},
      )
