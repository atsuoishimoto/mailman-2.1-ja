
c = "\x21\x23"
c1 = ord(c[0])
c2 = ord(c[1])

def _jistosjis(c1, c2): 
    if c1 & 1: 
        if c2 < 0x60: 
            c2 = c2 + 0x1f 
        else: 
            c2 = c2 + 0x20 
    else: 
        c2 = c2 + 0x7e 
     
    if c1 < 0x5f: 
        c1 = (c1 + 0xe1) >> 1 
    else: 
        c1 = (c1 + 0x161) >> 1 
     
    return c1, c2 

def _jistosjis2(c1, c2):
    if c1 <= 82:
        r1 = (c1 + 0xe1) / 2
    else:
        r1 = (c1 + 0x161) / 2
    
    if c1 % 2 == 1:
        if c2 <= 63+0x20:
            r2 = c2+0x1f
        else:
            r2 = c2+0x20
    else:
        r2 = c2+0x7e
    return r1, r2

def _sjistojis(c1, c2): 
    if c1 <= 0x9f: 
        if c2 < 0x9f: 
            c1 = (c1 << 1) - 0xe1 
        else: 
            c1 = (c1 << 1) - 0xe0 
    else: 
        if c2 < 0x9f: 
            c1 = (c1 << 1) - 0x161 
        else: 
            c1 = (c1 << 1) - 0x160 
 
    if c2 < 0x7f: 
        c2 = c2 - 0x1f 
    elif c2 < 0x9f: 
        c2 = c2 - 0x20 
    else: 
        c2 = c2 - 0x7e 
    return c1, c2 

def _sjistojis2(c1, c2):
    if 0x81 <= c1 <= 0x9f:
        r1 = c1*2-0x101
    else:
        r1 = c1*2-0x181

    if c2 < 0x9f:
        if c2 >= 0x80:
            r2 = c2-0x40
        else:
            r2 = c2-0x3f
    else:
        r1 += 1
        r2 = c2 - 0x9e
    
    return r1, r2


def _euctojis(c1, c2):
    return c1-0x80, c2-0x80

def _euctosjis(c1, c2):
    c1, c2 = _euctojis(c1, c2)
    return _jistosjis(c1, c2)


lines = open("c:\\src\\python\\pykf\\nectoeuc.txt").readlines()
lines = [l.split(",") for l in lines if l]
lines = [(int(l[0], 16), int(l[1], 16)) for l in lines]

for sjis, euc in lines:
    s1, s2 = _euctosjis(euc>>8, euc&0xff)
    s = s1 << 8 | s2
    print sjis == s, hex(sjis), hex(euc), hex(s)

