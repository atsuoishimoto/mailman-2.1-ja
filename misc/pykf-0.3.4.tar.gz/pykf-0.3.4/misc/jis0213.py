
# 6879����
f = open("jis0208.txt").readlines()
f = [l for l in f if l and l[0] != '#']
j0208 = [int(l.split()[1], 16) for l in f]

# 0213 1�ʂ�1908����
# �� 49
f = open("jisx0213code-csv.txt").readlines()
f = [l for l in f if l and l[0] != '#']
f = [l for l in f if l and l[0] == '1']
f = [l.split(",") for l in f]
f = [l for l in f if l[7] <> 'ffff']
j0213 = [int(l[4], 16) for l in f]

diff = [c for c in j0213 if c not in j0208]


seqs = []
seq = []
for c in diff:
    if not seq:
        seq.append(c)
    elif c == seq[-1]+1:
        seq.append(c)
    else:
        seqs.append(seq)
        seq = [c]

print '''
/* JIS X 0213 char table */

unsigned int tbl_jis0213[] = {
'''

for l in seqs:
    print "\t0x%x, %d," % (l[0], len(l))

print '''
    0xffff, 0xffff
};
'''

