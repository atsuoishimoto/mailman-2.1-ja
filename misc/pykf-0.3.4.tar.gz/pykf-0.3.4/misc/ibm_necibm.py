
#for i in range(0xF040, 0xF100):
#for i in range(0xFA40, 0xFC4C):
#for i in range(0xED40, 0xEEFE):
for i in range(0x8740, 0x879d):
    if i & 0xff:
        s = chr(i >> 8) + chr(i & 0xff)
        u = unicode(s, "mbcs")
        r = u.encode("mbcs")
        if ord(u) != 0x30fb:
            print "%x %s" % (i, s)


