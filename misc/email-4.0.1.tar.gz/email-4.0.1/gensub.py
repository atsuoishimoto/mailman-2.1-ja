#!/usr/bin/env python
# -*- coding: utf-8 -*-
import email.header

subj = u'日本語'
hdr1 = email.header.Header('Re: [mmjp-users 123]')
#hdr1.append(subj.encode('iso-2022-jp'), 'iso-2022-jp')
hdr1.append(subj, 'iso-2022-jp')
print hdr1
hdr2 = email.header.Header('Re:')
hdr2.append('[mmjp-users 123] ' + subj.encode('iso-2022-jp'), 'iso-2022-jp')
print hdr2
