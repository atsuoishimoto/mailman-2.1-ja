#!/usr/bin/env python

from distutils.core import setup, Extension

setup (name = "pykf",
       version = "0.3.0",
       description = "Japanese Kanji code filter",
       author = "Atsuo Ishimoto",
       author_email = "ishimoto@gembook.org",
       url = "http://www.gembook.jp",
       ext_modules = [
           Extension("pykf",
                     [
                         "src/pykf.c",
                          "src/converter.c",
                          "src/jis0213.c",
                          "src/mskanji.c",
                      ])])
